import React from 'react'

export default function About() {
  return (
    <section id="about" className="px-[140px] max-md:px-6 py-[120px] border-b border-[#1f1f1f]">
      {/* Section heading */}
      <div className="flex items-center gap-6 mb-10">
        <h2 className="font-semibold text-white leading-none whitespace-nowrap" style={{ fontSize: 'clamp(36px, 5vw, 60px)' }}>
          a dev for the love of the game
        </h2>
        <span className="flex-1 h-px bg-[#333]"></span>
      </div>

      <div className="grid md:grid-cols-2 gap-12 max-w-[1172px]">
        {/* Lead paragraph */}
        <p className="font-medium text-white leading-relaxed text-2xl">
          I'm Tobi, an enthusiastic backend developer who loves to build secure and scalable products with Go and the under appreciated Dart.
        </p>

        {/* Body */}
        <div className="text-[#808080] font-normal text-[16px] leading-[1.75] space-y-4">
          <p>
            I started learning Python about three years ago out of curiosity. In SS2, a teacher of mine encouraged
            my interest in programming, and I spent time learning and experimenting through resources like W3Schools.
          </p>
          <p>
            After taking a break to focus on my external exams, I came back wanting to build real applications.
            That led me to mobile development with Flutter and Dart.
          </p>
          <p>
            As I kept exploring, I became interested in backend systems and cybersecurity. I've experimented with
            C and Rust to understand performance and memory safety, and I also learned Go while working on backend
            projects. I'm still early in the journey, but I enjoy building and learning how systems work under the hood.
          </p>
        </div>
      </div>
    </section>
  )
}
