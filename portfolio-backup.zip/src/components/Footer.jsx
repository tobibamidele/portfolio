import React from 'react'

export default function Footer() {
  return (
    <footer className="px-[134px] max-md:px-6 h-[80px] flex items-center justify-between border-t border-[#1f1f1f]">
      <span className="font-bold text-[32px] text-white">tobi.</span>
      <span className="text-[#808080] font-light text-[14px] max-md:hidden">&copy; 2026 Tobi Bamidele</span>
    </footer>
  )
}
