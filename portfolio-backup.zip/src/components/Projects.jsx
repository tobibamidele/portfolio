import React from 'react'

// GitHub arrow icon from Figma
const githubArrowUrl = '/icons/arrow.svg'

const projects = [
  {
    category: 'LIBRARY',
    name: 'DOTH',
    description: 'Doth is a multi-provider OAuth2 library for dart servers. It requires minimal setup and has support for Google, GitHub, etc.',
    techs: ['DART', 'OAUTH2'],
    github: 'https://github.com/tobibamidele/doth',
  },
  {
    category: 'LIBRARY',
    name: 'IDAN',
    description: 'Idan is an extremely fast and lightweight authentication library for Go microservices with adapters for all popular databases.',
    techs: ['GO', 'AUTH'],
    github: 'https://github.com/tobibamidele/idan',
  },
  {
    category: 'BINARY',
    name: 'VAULTPAPI',
    description: 'VaultPapi is a self-hostable zero-knowledge secure password vault. Encrypts vault with AES-256-GCM and includes both server and extension.',
    techs: ['GO', 'TS', 'POSTGRES', 'VITE'],
    github: 'https://github.com/tobibamidele/vaultpapi',
  },
  {
    category: 'BINARY',
    name: 'MEM_VISUALIZER',
    description: 'Mem visualizer is a Rust based TUI that visualizes live memory usage across system processes with color-coded RSS stats and fuzzy search.',
    techs: ['RUST'],
    github: 'https://github.com/tobibamidele/mem_visualizer',
  },
  {
    category: 'MOBILE APP',
    name: 'KODO',
    description: 'Kodo is a chat application built with Flutter, Firebase, and Riverpod that supports real-time messages and basic chat functionality.',
    techs: ['FLUTTER', 'FIREBASE', 'RIVERPOD'],
    github: 'https://github.com/tobibamidele/kodo',
  },
  {
    category: 'RESEARCH',
    name: 'FAST JSON',
    description: 'FastJSON a Dart based JSON parser with in Rust that utilizes SIMD instructions to achieve 5x faster parsing speeds over traditional dart:convert.',
    techs: ['RUST', 'DART', 'SIMD'],
    github: 'https://github.com/tobibamidele/fastjson',
  },
]

function TechPill({ label }) {
  return (
    <span className="inline-flex items-center justify-center bg-[rgba(30,30,30,0.8)] text-white font-light text-[10px] tracking-widest px-3 h-[26px] whitespace-nowrap">
      {label}
    </span>
  )
}

function ProjectCard({ category, name, description, techs, github }) {
  return (
    <div className="bg-[#0a0a0a] border border-[#808080] p-[27px] flex flex-col justify-between h-[375px] group transition-all duration-200 hover:border-white">
      {/* Top */}
      <div>
        <p className="text-[#808080] font-light text-[13px] tracking-widest mb-2">{category}</p>
        <p className="text-white font-medium text-[15px] tracking-widest mb-5">{name}</p>
        <p className="text-white font-normal text-[13px] leading-relaxed">{description}</p>
      </div>

      {/* Bottom */}
      <div>
        {/* Tech pills */}
        <div className="flex flex-wrap gap-2 mb-4">
          {techs.map(t => <TechPill key={t} label={t} />)}
        </div>
        {/* Divider */}
        <div className="border-t border-[#333] pt-4">
          <a
            href={github}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-[#808080] font-light text-[13px] hover:text-white transition-colors duration-150 w-fit"
          >
            visit github
            <img src={githubArrowUrl} alt="" className="w-2 h-2 object-contain opacity-60 group-hover:opacity-100" />
          </a>
        </div>
      </div>
    </div>
  )
}

export default function Projects() {
  return (
    <section id="projects" className="px-[140px] max-md:px-6 py-[120px] border-b border-[#1f1f1f]">
      <div className="flex items-center gap-6 mb-12">
        <h2 className="font-semibold text-white leading-none whitespace-nowrap" style={{ fontSize: 'clamp(36px, 5vw, 60px)' }}>
          stuff i've built
        </h2>
        <span className="flex-1 h-px bg-[#333]"></span>
      </div>

      <div className="grid grid-cols-3 gap-0 max-lg:grid-cols-2 max-md:grid-cols-1">
        {projects.map(p => (
          <div key={p.name} className="border-[#808080] px-6 mb-10">
            <ProjectCard {...p} />
          </div>
        ))}
      </div>

      {/* See more link */}
      <div className="flex justify-center mt-10">
        <a
          href="https://github.com/tobibamdele"
          target="_blank"
          rel="noopener noreferrer"
          className="text-white font-normal text-[12px] underline tracking-widest hover:text-[#808080] transition-colors"
        >
          SEE MORE ON MY GITHUB ↗
        </a>
      </div>
    </section>
  )
}
