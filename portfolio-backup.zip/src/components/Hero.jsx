import React, { useEffect, useState } from 'react'

export default function Hero() {

  return (
    <section className="pt-[100px] min-h-screen flex flex-col justify-center px-[134px] max-md:px-6 relative">
      {/* Tag line with decorative lines */}
      <div className="animate-fade-up flex items-center gap-4 mb-4 mt-8">
        <span className="block w-[80px] h-px bg-[#808080]"></span>
        <span className="text-[#808080] text-[12px] font-normal tracking-[0.15em] whitespace-nowrap">
          NEWBIE DEV &amp; CYBER SECURITY ENTHUSIAST
        </span>
        <span className="block w-[66px] h-px bg-[#808080]"></span>
      </div>

      {/* "i am" pill + big name */}
      <div className="animate-fade-up delay-100 flex items-end gap-0 mb-0 leading-none">
        {/* "i am" white box */}
        <div
          className="inline-flex items-center justify-center bg-white mr-3"
          style={{ height: '70px', padding: '0 18px', borderRadius: '4px' }}
        >
          <span
            className="font-bold text-black whitespace-nowrap transition-opacity duration-300"
            style={{ fontSize: 'clamp(28px, 4vw, 58px)', opacity: 1 }}
          >
            i am
          </span>
        </div>
      </div>

      {/* Giant name */}
      <h1
        className="animate-fade-up delay-200 font-bold text-white leading-none whitespace-nowrap"
        style={{ fontSize: 'clamp(72px, 10vw, 128px)', letterSpacing: '-2px' }}
      >
        tobi.
      </h1>

      {/* Right side: subtext + buttons + stats */}
      <div className="animate-fade-up delay-300 flex flex-col md:flex-row gap-10 mt-8 max-w-[1172px]">
        {/* Description */}
        <div className="md:max-w-[537px]">
          <p className="text-[#808080] font-medium text-[15px] leading-relaxed mb-3">
            I build stuff. Mostly backend. Mostly Go or Dart.
          </p>
          <p className="text-[#808080] font-medium text-[15px] leading-relaxed">
            I love logic and building highly scalable, and secure backend systems that can withstand high-throughput
            environments.{' '}
            <span className="text-white font-bold">Mobile apps</span>,{' '}
            <span className="text-white font-bold">REST APIs</span>, built clean, built fast and built to last.
          </p>
        </div>

        {/* Right: buttons + stats */}
        <div className="ml-20 flex flex-col gap-6">
          {/* Buttons */}
          <div className="flex gap-4 flex-wrap">
            <a
              href="#projects"
              className="flex items-center justify-center bg-[#d9d9d9] text-black font-semibold text-[10px] tracking-widest w-[134px] h-[50px] transition-all duration-200 hover:bg-white hover:scale-[1.02]"
            >
              VIEW MY WORK
            </a>
            <a
              href="#contact"
              className="flex items-center justify-center bg-black text-white border border-white font-semibold text-[10px] tracking-widest w-[134px] h-[50px] transition-all duration-200 hover:bg-white hover:text-black"
            >
              CONTACT
            </a>
          </div>

          {/* Stats */}
          <div className="border-t border-[#333] pt-5">
            <div className="flex gap-12">
              <div>
                <p className="text-white font-normal text-[36px] leading-none">
                  1<span className="text-[16px]">+</span>
                </p>
                <p className="text-white text-[12px] tracking-widest mt-1">YEARS EXP</p>
              </div>
              <div>
                <p className="text-white font-normal text-[36px] leading-none">
                  10<span className="text-[16px]">+</span>
                </p>
                <p className="text-white text-[12px] tracking-widest mt-1">PROJECTS</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Down indicator */}
      <a
        href="#about"
        className="animate-fade-up delay-500 absolute bottom-10 left-1/2 -translate-x-1/2 w-[50px] h-[50px] rounded-full border border-[#808080] flex items-center justify-center hover:border-white transition-colors duration-200 max-md:hidden"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#808080" strokeWidth="2">
          <polyline points="6 9 12 15 18 9"/>
        </svg>
      </a>
    </section>
  )
}
